<?php
try {
      $conn = new PDO('mysql:host=localhost;dbname=cyb_challenge', 'cyb', 'cyb');
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch (Exception $e)
{
      return ["PDOException"=>$e->getMessage()];
}
?>
