<?php
	// Connect to database
	require 'dbConnect.php';
?>

<html>
  <head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Source+Code+Pro" rel="stylesheet">
    <link href="CSS/cyb.css" rel="stylesheet">
  </head>
  
  <div class="container">
    
  <body class="bg">
    <div class="header text-center center-block">
        <h1>Cyber Hack</h1>
        <p id="welcome"> hello friend you have been hacked</p>
        <!--<img src="IMG/robot-hack.jpg">-->
    </div>
    
  <div class="intro">
    <div class="text-center center-block">
        <p id="text1">
            <form method="post" action="search.php">
                <input type="text" name="search_query" placeholder="Search for data...">
                <input type="submit" value="Search">
            </form>
        </p>
    </div>
  </div>

  <div class="datas">
    <div class="text-center center-block"></div>
        <h1 id="table-heading">Confidentials informations</h1>
        <table>
            				<thead>
                				<tr>
                    				<th>ID</th>
                    				<th>Name</th>
                				</tr>

       	<?php
       		// Get search query from form submission
			$search_query = $_POST['search_query'];

			// Perform SQL query to search for matching data
			$sql = "SELECT * FROM data WHERE username LIKE '%$search_query%'";

			// Display results on web page
			$count=0;
			foreach ($conn->query($sql)  as $row) {
					echo"
            				</thead>
            				<tbody>
                				<tr>";
			        echo 			"<td>" . $row["user_id"] . "</td>";
			        echo 			"<td>" . $row["username"] . "</td>";
			        echo 		"</tr>
            				</tbody>
        				";
			        $count++;
			}
			if ($count===0) echo "No results";
       	?>
       	</table>
    </div>
  </div>
  <div class="skill">
    <h5 id="text2">mr.robot: if you ask me about my hacking skill</br>
        mr.robot: you're asking a wrong question </br>
        mr.robot: i hack when i am sad</br>
        mr.robot: i hack everyday</br>
        mr.robot: i know who you are, i know what you did, i can see you.</br>
        mr.robot: why don't you join me, to save this world </br>
        mr.robot: just click those links down here:</br>
  </h5>
  </div>

  </body>
</html>
